import React from "react";
import { Form, Button, Container, Row, Col } from "react-bootstrap";

import { addUser } from "../apis/crud";

const UserRegister = () => {
    

    const saveUser = (values) => {
        values.preventDefault();

        const dataUser = {
            nombre: values.target[0].value,
            Telefono: values.target[1].value,
            direccion: values.target[2].value,
            fecha_nacimiento: values.target[3].value,
            // id: user.uid,
        };

        addUser(dataUser, (res) => {
            console.log(res);
            if (res === "Success") {
                // user.flagNewUser = false;
                // localStorage.setItem("user", JSON.stringify(dataUser));
                // window.location.href = "http://localhost:3000/home";
                console.log('Posteo exitoso!');
            } else {
                alert("Paila");
            }
        });
    };

    return (
        <>
            <Container >
                <Row className="justify-content-md-center">
                    <Col lg="6">
                        <Form onSubmit={saveUser}>
                            <Form.Group className="mb-3" controlId="nombre">
                                <Form.Label>Nombre</Form.Label>
                                <Form.Control type="text" placeholder="Ingrese su Nombre" />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="Telefono">
                                <Form.Label>Telefono</Form.Label>
                                <Form.Control type="tel" placeholder="Ingrese su telefono" />
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="fecha_nacimiento">
                                <Form.Label>Fecha de Nacimiento</Form.Label>
                                <Form.Control type="text" placeholder="Ingrese su fecha de nacimiento" />
                            </Form.Group>

                            <Form.Group className="mb-3 address" controlId="direccion">
                                <Form.Label>Dirección</Form.Label>
                                <Form.Control type="text" placeholder="Ingrese su dirección" />
                            </Form.Group>
                            
                            <Row>
                                <Button variant="dark" type="submit">
                                    Enviar
                                </Button>
                                
                                        
                            </Row>
                            <br />
                            <br />
                        </Form>
                    </Col>
                </Row>
            </Container>
        </>
    );
};

export default UserRegister;