import React from 'react'
import {Container, Table, Button} from 'react-bootstrap'
import { searchUser } from "../apis/crud";




const ShowUser = () => {

  

    const datos = searchUser();

    
    return (
        <Container>

           <Table striped bordered hover>
  <thead>
    <tr>
      <th>#</th>
      <th>Nombre</th>
      <th>Telefono</th>
      <th>Dirección</th>
      <th>Fecha Nacimiento</th>
      <th>Email</th>
      
    </tr>
  </thead>
  <tbody>
    
        {datos.map((data,i)=>[
            <tr key={i}>
            <td>{i+1}</td>
            <td>{data.nombre}</td>
            <td>{data.Telefono}</td>
            <td>{data.direccion}</td>
            <td>{data.fecha_nacimiento}</td>
            <td>{data.email}</td>
            <td>
            <th>
      <Button variant="btn btn-secondary" type="submit"  >Eliminar</Button>
      </th>
            </td>
            </tr>
        ])}
      

      
   
    
    
  </tbody>
</Table>
        </Container>
    )
}

export default ShowUser
