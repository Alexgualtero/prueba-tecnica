import React from "react";
import { Navigate } from "react-router";
import ShowUser from "../components/ShowUser";
import UserRegister from "../components/UserRegister";

const Register = () => {
    var user = JSON.parse(localStorage.getItem("user"));
    if (!user) {
        return <Navigate to="/" />;
    } //else if (user.flagNewUser == false) {
    //return <Navigate to="/home" />;
    //}

    return (
        <>
        <UserRegister />;
        <ShowUser />
        </>
    )

    
}

export default Register;