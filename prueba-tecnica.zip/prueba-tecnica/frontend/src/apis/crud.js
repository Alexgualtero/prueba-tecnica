import axios from 'axios';
import { useEffect, useState, } from 'react';




const baseUrl = 'http://localhost:5000';

export const searchUser = () => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const [datos, setDatos] = useState([]);
    // eslint-disable-next-line react-hooks/rules-of-hooks
    useEffect(() => {
        fetch(`${baseUrl}/users`)
            .then(res => res.json())
            .then(data => {
                setDatos(data)
            })
            
        
    },[]);
    return datos;
    
}

export const addUser = (user, callback) => {
    axios.post(`${baseUrl}/users`, user).then((res) => {
        callback(res.data);
    }).catch((error) => {
        callback(error);
    });
}


